# StackerPi
Macro focus stacker controller script for Raspberry Pi 2
